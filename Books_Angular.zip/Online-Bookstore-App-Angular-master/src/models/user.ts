export class User {
    id: any;
    email: any;
    name: any;
    userName: any;
    password: any;
    mobileNumber: any;
    role: any;
    isVerify: any;
}
